import asyncio
import time
import json
from typing import Dict, List, Any
from asyncio import Semaphore
from app.audio.service import TTSService, VOICE_MAPPING

MAX_CONCURRENT_TTS = 3
AUDIO_TASK_HEARTBEAT = 5  # giây

class AudioTaskManager:
    def __init__(self):
        self.semaphore = Semaphore(MAX_CONCURRENT_TTS)
        self.tasks_db: Dict[str, Dict[str, Any]] = {}
        self.subscribers: List[asyncio.Queue] = []

    async def register_subscriber(self) -> asyncio.Queue:
        q = asyncio.Queue()
        self.subscribers.append(q)
        return q

    def unregister_subscriber(self, q: asyncio.Queue):
        if q in self.subscribers:
            self.subscribers.remove(q)

    async def broadcast(self, event_type: str, data: dict):
        message = f"event: {event_type}\ndata: {json.dumps(data)}\n\n"
        for q in self.subscribers:
            await q.put(message)

    async def enqueue_homestay_audio(self, poi_id: str, title: str, description: str, db_session=None):
        task_id = f"task_{poi_id}_{int(time.time())}"
        self.tasks_db[task_id] = {
            "task_id": task_id,
            "poi_id": poi_id,
            "status": "queued",
            "progress": 0,
            "languages": list(VOICE_MAPPING.keys()),
            "completed_langs": [],
            "last_heartbeat": time.time(),
            "control": "run"
        }
        await self.broadcast("task_updated", self.tasks_db[task_id])
        asyncio.create_task(self._process_task(task_id, title, description, db_session))
        return task_id

    async def _process_task(self, task_id: str, title: str, description: str, db_session=None):
        task = self.tasks_db[task_id]
        task["status"] = "running"
        await self.broadcast("task_updated", task)

        full_text = f"{title}. {description}"
        total_langs = len(VOICE_MAPPING)

        # Heartbeat loop
        async def heartbeat_loop():
            while task["status"] in ["running", "paused"]:
                task["last_heartbeat"] = time.time()
                await self.broadcast("heartbeat", {"task_id": task_id, "timestamp": task["last_heartbeat"]})
                await asyncio.sleep(AUDIO_TASK_HEARTBEAT)

        hb_task = asyncio.create_task(heartbeat_loop())

        try:
            for lang in VOICE_MAPPING.keys():
                while task["control"] == "pause":
                    task["status"] = "paused"
                    await self.broadcast("task_updated", task)
                    await asyncio.sleep(1)

                if task["control"] == "cancel":
                    task["status"] = "cancelled"
                    await self.broadcast("task_updated", task)
                    hb_task.cancel()
                    return

                task["status"] = "running"

                async with self.semaphore:
                    _, _, md5_hash = await TTSService.generate_tts(full_text, lang)
                    task["completed_langs"].append(lang)
                    task["progress"] = int((len(task["completed_langs"]) / total_langs) * 100)
                    await self.broadcast("task_updated", task)

                    # Public-English Readiness Gate: Mở công khai khi bản tiếng Anh tạo xong
                    if lang == "en" and db_session:
                        # Giả định cập nhật cờ is_active trong DB
                        # db_session.execute("UPDATE homestays SET is_active=true WHERE id=:id AND activation_requested=true", {"id": task["poi_id"]})
                        pass

            task["status"] = "completed"
            await self.broadcast("task_updated", task)
        except Exception as e:
            task["status"] = "failed"
            task["error"] = str(e)
            await self.broadcast("task_updated", task)
        finally:
            hb_task.cancel()

    def update_task_control(self, task_id: str, action: str):
        if task_id in self.tasks_db:
            self.tasks_db[task_id]["control"] = action

audio_task_manager = AudioTaskManager()