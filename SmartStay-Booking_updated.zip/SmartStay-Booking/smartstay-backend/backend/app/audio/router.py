from fastapi import APIRouter, HTTPException, Path
from app.audio.task_manager import audio_task_manager

router = APIRouter(prefix="/api/v1/audio", tags=["audio"])

@router.get("/languages")
async def get_supported_languages():
    return {"languages": ["vi", "en", "zh", "ja", "ko"]}

# (Thêm các route này vào router audio đã tạo)

@router.post("/admin/audio-tasks/{task_id}/pause")
async def pause_audio_task(task_id: str = Path(...)):
    audio_task_manager.update_task_control(task_id, "pause")
    return {"message": f"Task {task_id} marked as pause"}

@router.post("/admin/audio-tasks/{task_id}/resume")
async def resume_audio_task(task_id: str = Path(...)):
    audio_task_manager.update_task_control(task_id, "run")
    return {"message": f"Task {task_id} marked as resume"}

@router.post("/admin/audio-tasks/{task_id}/cancel")
async def cancel_audio_task(task_id: str = Path(...)):
    audio_task_manager.update_task_control(task_id, "cancel")
    return {"message": f"Task {task_id} marked as cancel"}