import os
import hashlib
import time
from typing import Dict, Optional
import edge_tts
from deep_translator import GoogleTranslator

# 5 giọng đọc neural chủ đạo cho 5 ngôn ngữ
VOICE_MAPPING = {
    "vi": "vi-VN-HoaiMyNeural",
    "en": "en-US-JennyNeural",
    "zh": "zh-CN-XiaoxiaoNeural",
    "ja": "ja-JP-NanamiNeural",
    "ko": "ko-KR-SunHiNeural"
}

VOICE_CATALOG_TTL = 6 * 3600  # 6 giờ * 3600 giây (1 giờ)
_voice_catalog_cache: Dict[str, any] = {"timestamp": 0, "data": {}}
AUDIO_STORAGE_DIR = os.getenv("AUDIO_STORAGE_DIR", "./static/audio")

os.makedirs(AUDIO_STORAGE_DIR, exist_ok=True)

class TTSService:
    @staticmethod
    def get_voice_catalog() -> Dict[str, str]:
        now = time.time()
        if now - _voice_catalog_cache["timestamp"] < VOICE_CATALOG_TTL and _voice_catalog_cache["data"]:
            return _voice_catalog_cache["data"]
        
        _voice_catalog_cache["data"] = VOICE_MAPPING
        _voice_catalog_cache["timestamp"] = now
        return VOICE_MAPPING

    @staticmethod
    def compute_md5(text: str, lang: str) -> str:
        raw_key = f"{text}:{lang}".encode('utf-8')
        return hashlib.md5(raw_key).hexdigest()

    @staticmethod
    def translate_text(text: str, target_lang: str) -> str:
        if target_lang == "vi":
            return text
        try:
            return GoogleTranslator(source='auto', target=target_lang).translate(text)
        except Exception as e:
            print(f"[Translation Error] {e}")
            return text

    @classmethod
    async def generate_tts(cls, text: str, lang: str) -> tuple[str, bool, str]:
        """
        Trả về: (file_path, is_cache_hit, md5_hash)
        """
        translated_text = cls.translate_text(text, lang)
        md5_hash = cls.compute_md5(translated_text, lang)
        filename = f"{md5_hash}.mp3"
        file_path = os.path.join(AUDIO_STORAGE_DIR, filename)

        # Cơ chế chống tạo trùng (Cache HIT)
        if os.path.exists(file_path):
            return file_path, True, md5_hash

        voice = VOICE_MAPPING.get(lang, VOICE_MAPPING["en"])
        communicate = edge_tts.Communicate(translated_text, voice)
        await communicate.save(file_path)
        
        return file_path, False, md5_hash

    @staticmethod
    def format_audio_url(base_url: str, md5_hash: str, updated_at: int, lang: str) -> str:
        return f"{base_url}/static/audio/{md5_hash}.mp3?v={updated_at}&l={lang}"