from sqlalchemy import Column, String, Integer, Boolean, Float, DateTime, Text, CompoundIndex, Index
from datetime import datetime
from app.core.database import Base

class AudioTaskModel(Base):
    __tablename__ = "audio_tasks"

    task_id = Column(String(100), primary_key=True)
    poi_id = Column(String(50), index=True, nullable=False)
    status = Column(String(20), default="queued")  # queued, running, paused, completed, failed, cancelled
    progress = Column(Integer, default=0)
    control = Column(String(20), default="run")  # run, pause, cancel
    completed_langs = Column(Text, default="[]") # Lưu JSON string
    last_heartbeat = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

class POILocalizationModel(Base):
    __tablename__ = "poi_localizations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    poi_id = Column(String(50), nullable=False)
    lang = Column(String(10), nullable=False)
    title = Column(Text)
    description = Column(Text)
    audio_url = Column(Text)
    is_fallback = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("idx_poi_lang", "poi_id", "lang", unique=True),
    )

class LocalizationRateLimitModel(Base):
    __tablename__ = "localization_rate_limits"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_ip = Column(String(45), index=True, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

class UITranslationBundleModel(Base):
    __tablename__ = "ui_translation_bundles"

    locale = Column(String(10), primary_key=True)
    source_hash = Column(String(64), nullable=False)
    status = Column(String(20), default="pending") # pending, ready
    bundle_json = Column(Text, nullable=False) # JSON chứa dict key-value
    updated_at = Column(DateTime, default=datetime.utcnow)