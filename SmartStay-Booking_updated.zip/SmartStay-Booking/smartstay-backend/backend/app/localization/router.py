import math
from fastapi import APIRouter

router = APIRouter(prefix="/api/v1/localizations", tags=["localization"])

@router.get("/ping")
async def ping_localization():
    return {"lane": "localization", "status": "ok"}

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0  # Bán kính Trái Đất (m)
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c  # Mét

# Trong API POST /localizations/prepare-hotset:
# Lọc danh sách POIs thỏa mãn: haversine_distance(user_lat, user_lng, poi.lat, poi.lng) <= 1500
# Lấy tối đa 10 POIs gần nhất và ưu tiên sinh MP3 với Semaphore = 3.