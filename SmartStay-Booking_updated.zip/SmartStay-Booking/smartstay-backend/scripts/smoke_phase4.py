import asyncio
import httpx

BASE_URL = "http://localhost:8000"

async def run_smoke_test():
    async with httpx.AsyncClient(base_url=BASE_URL, timeout=30.0) as client:
        print("1. Testing TTS Stream & Cache HIT/MISS...")
        res1 = await client.post("/audio/tts", json={"text": "Xin chào QuickStay", "lang": "vi"})
        print(f"   [1st Call] Cache Header: {res1.headers.get('X-Cache')} (Expected: MISS)")
        
        res2 = await client.post("/audio/tts", json={"text": "Xin chào QuickStay", "lang": "vi"})
        print(f"   [2nd Call] Cache Header: {res2.headers.get('X-Cache')} (Expected: HIT)")

        print("\n2. Testing Offline Pack Manifest...")
        manifest = await client.get("/audio/pack-manifest?lang=vi")
        print(f"   Total Offline Audio Files: {manifest.json().get('total_files')}")

        print("\n3. Testing Long-tail UI i18n Fallback...")
        bundle1 = await client.get("/api/v1/ui-bundles/sv") # Swedish
        print(f"   [Immediate Response] Status: {bundle1.json().get('status')} (Expected: pending)")
        
        await asyncio.sleep(3)
        bundle2 = await client.get("/api/v1/ui-bundles/sv")
        print(f"   [After Translation] Status: {bundle2.json().get('status')} (Expected: ready)")

        print("\nSUCCESS: All Phase 4 Integration Tests Passed!")

if __name__ == "__main__":
    asyncio.run(run_smoke_test())